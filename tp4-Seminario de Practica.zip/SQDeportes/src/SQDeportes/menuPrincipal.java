package SQDeportes;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;

import ConexionBD.ConexionBD;
import ConexionBD.ControladorCliente;

public class menuPrincipal {
    public static void main(String[] args) {
        // Conectar a la base de datos
        Connection conexion = ConexionBD.conectar();
        if (conexion == null) {
            System.out.println("Error al conectar a la base de datos. El programa terminará.");
            return; // Si no se puede conectar, terminar el programa
        }

        Scanner scanner = new Scanner(System.in); // Crear un escáner para leer la entrada del usuario
        boolean exit = false; // Variable para controlar la salida del menú principal
        ControladorCliente controladorCliente = new ControladorCliente(conexion); // Crear un controlador de clientes

        while (!exit) {
            // Mostrar menú principal
            System.out.println("**************************************************");
            System.out.println(" Bienvenidos al Sistema de Gestion de SQDeportes:");
            System.out.println("**************************************************");
            System.out.println(" Por favor, Seleccione una opcion:");
            System.out.println("**************************************************");
            System.out.println(" 1. Gestion de Clientes");
            System.out.println(" 2. Gestion de Empleados");
            System.out.println(" 3. Gestion de Proveedores");
            System.out.println(" 4. Gestion de Productos");
            System.out.println(" 5. Gestion de Pedidos");
            System.out.println(" 6. Gestion de Facturas");
            System.out.println(" 7. Salir");

            try {
                int choice = scanner.nextInt(); // Leer la opción seleccionada por el usuario
                switch (choice) {
                    case 1:
                        mostrarMenuClientes(controladorCliente, scanner); // Mostrar el menú de gestión de clientes
                        break;
                    case 7:
                        exit = true; // Salir del programa
                        System.out.println("Gracias por utilizar el Sistema de Gestion de SQDeportes.");
                        break;
                    default:
                        System.out.println("Opción no válida, intente nuevamente.");
                        break;
                }
            } catch (InputMismatchException e) {
                System.out.println("Entrada no válida, intente nuevamente.");
                scanner.next(); // Limpiar la entrada inválida
            } catch (SQLException e) {
                System.out.println("Error en la base de datos: " + e.getMessage());
            }
        }
        scanner.close(); // Cerrar el escáner
        try {
            conexion.close(); // Cerrar la conexión a la base de datos
        } catch (SQLException e) {
            System.out.println("Error al cerrar la conexión a la base de datos: " + e.getMessage());
        }
    }

    // Método para mostrar el menú de gestión de clientes
    private static void mostrarMenuClientes(ControladorCliente controladorCliente, Scanner scanner) throws SQLException {
        boolean exit = false; // Variable para controlar la salida del menú de clientes
        while (!exit) {
            // Mostrar menú de gestión de clientes
            System.out.println("**************************************************");
            System.out.println(" Gestion de Clientes");
            System.out.println("**************************************************");
            System.out.println(" 1. Alta de Cliente");
            System.out.println(" 2. Baja de Cliente");
            System.out.println(" 3. Modificacion de Cliente");
            System.out.println(" 4. Visualizacion de Cliente");
            System.out.println(" 5. Listado de Clientes");
            System.out.println(" 6. Volver al menu principal");

            try {
                int choice = scanner.nextInt(); // Leer la opción seleccionada por el usuario
                switch (choice) {
                    case 1:
                        controladorCliente.altaCliente(); // Dar de alta a un cliente
                        break;
                    case 2:
                        controladorCliente.bajaCliente(); // Dar de baja a un cliente
                        break;
                    case 3:
                        controladorCliente.modificarCliente(); // Modificar los datos de un cliente
                        break;
                    case 4:
                        controladorCliente.visualizarCliente(); // Visualizar los datos de un cliente
                        break;
                    case 5:
                        controladorCliente.listarClientes(); // Listar todos los clientes
                        break;
                    case 6:
                        exit = true; // Volver al menú principal
                        break;
                    default:
                        System.out.println("Opción no válida, intente nuevamente.");
                        break;
                }
            } catch (InputMismatchException e) {
                System.out.println("Entrada no válida, intente nuevamente.");
                scanner.next(); // Limpiar la entrada inválida
            }
        }
    }
}
