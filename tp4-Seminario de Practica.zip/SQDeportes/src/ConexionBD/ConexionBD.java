package ConexionBD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionBD {
    // Constantes para la URL de conexión, usuario y contraseña de la base de datos
    private static final String URL = "jdbc:mysql://localhost:3306/sqdeportes";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    // Método estático para establecer una conexión a la base de datos
    public static Connection conectar() {
        Connection conexion = null; // Variable para almacenar la conexión
        try {
            // Intentar establecer una conexión utilizando los parámetros proporcionados
            conexion = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            // Capturar y mostrar cualquier excepción de SQL que ocurra durante la conexión
            System.out.println("Error al conectar a la base de datos: " + e.getMessage());
        }
        return conexion; // Devolver la conexión (puede ser null si ocurrió un error)
    }
}
