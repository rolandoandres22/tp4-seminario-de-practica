package ConexionBD;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import SQDeportes.Cliente;

public class ControladorCliente {
    private ModeloCliente modelo; // Modelo que maneja la lógica de negocio y acceso a datos
    private VistaCliente vista; // Vista que maneja la interacción con el usuario

    // Constructor que inicializa el modelo y la vista usando una conexión a la base de datos
    public ControladorCliente(Connection conexion) {
        this.modelo = new ModeloCliente(conexion);
        this.vista = new VistaCliente();
    }

    // Método para dar de alta a un cliente
    public void altaCliente() throws SQLException {
        Cliente nuevoCliente = vista.solicitarDatosCliente(); // Solicita los datos del nuevo cliente al usuario
        modelo.insertarCliente(nuevoCliente); // Inserta el nuevo cliente en la base de datos
        System.out.println("Cliente dado de alta correctamente.");
    }

    // Método para dar de baja a un cliente
    public void bajaCliente() throws SQLException {
        int idCliente = vista.solicitarIdCliente(); // Solicita el ID del cliente a dar de baja
        modelo.eliminarCliente(idCliente); // Elimina el cliente de la base de datos
        System.out.println("Cliente dado de baja correctamente.");
    }

    // Método para modificar los datos de un cliente
    public void modificarCliente() throws SQLException {
        int id = vista.solicitarIdCliente(); // Solicita el ID del cliente a modificar
        Cliente clienteModificado = vista.solicitarDatosCliente(); // Solicita los nuevos datos del cliente al usuario
        clienteModificado.setIdCliente(id); // Establece el ID del cliente modificado
        modelo.modificarCliente(clienteModificado); // Actualiza el cliente en la base de datos
        System.out.println("Cliente modificado correctamente.");
    }

    // Método para visualizar los datos de un cliente
    public void visualizarCliente() throws SQLException {
        int idCliente = vista.solicitarIdCliente(); // Solicita el ID del cliente a visualizar
        Cliente cliente = modelo.consultarCliente(idCliente); // Consulta el cliente en la base de datos
        vista.mostrarCliente(cliente); // Muestra los datos del cliente
    }

    // Método para listar todos los clientes
    public void listarClientes() throws SQLException {
        List<Cliente> clientes = modelo.listarClientes(); // Consulta la lista de clientes en la base de datos
        vista.mostrarClientes(clientes); // Muestra la lista de clientes
    }
}
