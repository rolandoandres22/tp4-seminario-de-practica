package ConexionBD;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import SQDeportes.Cliente;

public class ModeloCliente {
    private Connection conexion; // Conexión a la base de datos

    // Constructor que inicializa la conexión a la base de datos
    public ModeloCliente(Connection conexion) {
        this.conexion = conexion;
    }

    // Método para insertar un nuevo cliente en la base de datos
    public void insertarCliente(Cliente cliente) throws SQLException {
        String sql = "INSERT INTO clientes (nombre, DNI, direccion, telefono, localidad, provincia, cuentaCorriente) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setString(1, cliente.getNombre());
            stmt.setString(2, cliente.getDNI());
            stmt.setString(3, cliente.getDireccion());
            stmt.setString(4, cliente.getTelefono());
            stmt.setString(5, cliente.getLocalidad());
            stmt.setString(6, cliente.getProvincia());
            stmt.setDouble(7, cliente.getCuentaCorriente());
            stmt.executeUpdate(); // Ejecuta la inserción
        }
    }

    // Método para eliminar un cliente de la base de datos utilizando su ID
    public void eliminarCliente(int idCliente) throws SQLException {
        String sql = "DELETE FROM clientes WHERE idCliente = ?";
        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setInt(1, idCliente);
            stmt.executeUpdate(); // Ejecuta la eliminación
        }
    }

    // Método para modificar los datos de un cliente existente en la base de datos
    public void modificarCliente(Cliente cliente) throws SQLException {
        String sql = "UPDATE clientes SET nombre = ?, DNI = ?, direccion = ?, telefono = ?, localidad = ?, provincia = ?, cuentaCorriente = ? WHERE idCliente = ?";
        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setString(1, cliente.getNombre());
            stmt.setString(2, cliente.getDNI());
            stmt.setString(3, cliente.getDireccion());
            stmt.setString(4, cliente.getTelefono());
            stmt.setString(5, cliente.getLocalidad());
            stmt.setString(6, cliente.getProvincia());
            stmt.setDouble(7, cliente.getCuentaCorriente());
            stmt.setInt(8, cliente.getIdCliente());
            stmt.executeUpdate(); // Ejecuta la actualización
        }
    }

    // Método para consultar los datos de un cliente en la base de datos utilizando su ID
    public Cliente consultarCliente(int idCliente) throws SQLException {
        String sql = "SELECT * FROM clientes WHERE idCliente = ?";
        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setInt(1, idCliente);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                // Si se encuentra el cliente, crear y devolver un objeto Cliente con sus datos
                return new Cliente(
                    rs.getInt("idCliente"),
                    rs.getString("nombre"),
                    rs.getString("direccion"),
                    rs.getString("telefono"),
                    rs.getString("localidad"),
                    rs.getString("provincia"),
                    rs.getInt("idCliente"),
                    rs.getString("DNI"),
                    rs.getDouble("cuentaCorriente")
                );
            }
        }
        return null; // Si no se encuentra el cliente, devolver null
    }

    // Método para listar todos los clientes de la base de datos
    public List<Cliente> listarClientes() throws SQLException {
        List<Cliente> clientes = new ArrayList<>();
        String sql = "SELECT * FROM clientes";
        try (PreparedStatement stmt = conexion.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                // Agregar cada cliente encontrado a la lista de clientes
                clientes.add(new Cliente(
                    rs.getInt("idCliente"),
                    rs.getString("nombre"),
                    rs.getString("direccion"),
                    rs.getString("telefono"),
                    rs.getString("localidad"),
                    rs.getString("provincia"),
                    rs.getInt("idCliente"),
                    rs.getString("DNI"),
                    rs.getDouble("cuentaCorriente")
                ));
            }
        }
        return clientes; // Devolver la lista de clientes
    }
}
