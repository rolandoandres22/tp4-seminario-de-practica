package ConexionBD;

import java.util.List;
import java.util.Scanner;

import SQDeportes.Cliente;

public class VistaCliente {
    private Scanner scanner;
    private Scanner scanner2;

    // Constructor que inicializa los escáneres para la entrada del usuario
    public VistaCliente() {
        this.scanner = new Scanner(System.in);
        this.scanner2 = new Scanner(System.in);
    }

    // Método para solicitar los datos de un cliente al usuario
    public Cliente solicitarDatosCliente() {
        System.out.print("Ingrese el nombre del cliente: ");
        String nombre = scanner.nextLine();
        System.out.print("Ingrese el DNI del cliente: ");
        String DNI = scanner.nextLine();
        System.out.print("Ingrese la direccion del cliente: ");
        String direccion = scanner.nextLine();
        System.out.print("Ingrese el telefono del cliente: ");
        String telefono = scanner.nextLine();
        System.out.print("Ingrese la localidad del cliente: ");
        String localidad = scanner.nextLine();
        System.out.print("Ingrese la provincia del cliente: ");
        String provincia = scanner.nextLine();
        System.out.print("Ingrese la cuenta corriente del cliente: ");
        double cuentaCorriente = scanner.nextDouble();
        scanner.nextLine(); // Consumir el salto de línea pendiente

        // Crear y devolver un nuevo objeto Cliente con los datos ingresados
        return new Cliente(0, nombre, direccion, telefono, localidad, provincia, 0, DNI, cuentaCorriente);
    }

    // Método para solicitar el ID de un cliente al usuario
    public int solicitarIdCliente() {
        System.out.print("Ingrese el ID del cliente: ");
        int id = scanner2.nextInt(); // Leer el ID utilizando un segundo escáner
        return id;
    }

    // Método para mostrar los datos de un cliente
    public void mostrarCliente(Cliente cliente) {
        if (cliente != null) {
            System.out.println("ID: " + cliente.getIdCliente());
            System.out.println("Nombre: " + cliente.getNombre());
            System.out.println("DNI: " + cliente.getDNI());
            System.out.println("Direccion: " + cliente.getDireccion());
            System.out.println("Telefono: " + cliente.getTelefono());
            System.out.println("Localidad: " + cliente.getLocalidad());
            System.out.println("Provincia: " + cliente.getProvincia());
            System.out.println("Cuenta Corriente: " + cliente.getCuentaCorriente());
        } else {
            System.out.println("Cliente no encontrado.");
        }
    }

    // Método para mostrar los datos de una lista de clientes
    public void mostrarClientes(List<Cliente> clientes) {
        for (Cliente cliente : clientes) {
            mostrarCliente(cliente); // Mostrar los datos de cada cliente
            System.out.println("----------------------------");
        }
    }
}
